
(function(){
  const data = window.EDUCANET_DATA || {};
  const cards = document.getElementById('cards');
  const search = document.getElementById('search');
  const toggle = document.getElementById('toggle-theme');

  const descriptions = {
    "Aritmética": "Operaciones, problemas y trucos de cálculo para dominar la base numérica.",
    "Álgebra": "Ecuaciones, polinomios y técnicas para modelar y resolver.",
    "Geometría": "Figuras, áreas y teoremas con enfoque visual.",
    "Trigonometría": "Razones trigonométricas, identidades y aplicaciones.",
    "Razonamiento Matemático": "Estrategias y heurísticas para pensar matemáticamente.",
    "Razonamiento Lógico": "Lógica proposicional, tablas de verdad y argumentos.",
    "Física": "Mecánica, ondas, electricidad y más con ejercicios.",
    "Química": "Estructura, reacciones y resolución de problemas.",
    "Biología": "Procesos biológicos y comprensión de la vida.",
    "Razonamiento Verbal": "Comprensión lectora, sinónimos, antónimos e inferencias.",
    "Gramática": "Normas, sintaxis y morfología del español.",
    "Literatura": "Géneros, autores y análisis de obras.",
    "Economía": "Conceptos y problemas económicos aplicados.",
    "Geografía y Cívica": "Espacio geográfico, ciudadanía y normas.",
    "Historia del Perú": "Procesos históricos y personajes clave.",
    "Obras Literarias (Resúmenes)": "Resúmenes descargables de obras clásicas."
  };

  const icons = {
    "Aritmética":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f522.svg",
    "Álgebra":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/0031-20e3.svg",
    "Geometría":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f9ee.svg",
    "Trigonometría":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f4c8.svg",
    "Razonamiento Matemático":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f9e0.svg",
    "Razonamiento Lógico":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f5a5.svg",
    "Física":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/26a1.svg",
    "Química":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/2697.svg",
    "Biología":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f331.svg",
    "Razonamiento Verbal":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f4ac.svg",
    "Gramática":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f58a.svg",
    "Literatura":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f4d6.svg",
    "Economía":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f4b0.svg",
    "Geografía y Cívica":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f30e.svg",
    "Historia del Perú":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f9ed.svg",
    "Obras Literarias (Resúmenes)":"https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f4d3.svg"
  };

  function render(list){
    cards.innerHTML = "";
    list.forEach(([name, url]) => {
      const card = document.createElement('article');
      card.className = 'card';
      card.innerHTML = `
        <span class="badge">${name.includes('Razonamiento') ? 'Pensamiento' : 'Curso'}</span>
        <img alt="${name}" loading="lazy" width="36" height="36" src="${icons[name] || icons['Razonamiento Verbal']}" />
        <h3>${name}</h3>
        <p>${descriptions[name] || 'Recurso académico'}</p>
        <div class="actions">
          <a class="btn" href="${url}" target="_blank" rel="noopener">Ver video‑clases</a>
        </div>
      `;
      cards.appendChild(card);
    });
  }

  const entries = Object.entries(data);
  render(entries);

  // Search
  search?.addEventListener('input', (e)=>{
    const q = e.target.value.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    const filtered = entries.filter(([k]) => k.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').includes(q));
    render(filtered);
  });

  // Theme toggle
  function setTheme(light){
    document.documentElement.classList.toggle('light', light);
    toggle.textContent = light ? 'Modo oscuro' : 'Modo claro';
  }
  let light = false;
  toggle?.addEventListener('click', ()=>{ light = !light; setTheme(light); });
  // Respect prefers-color-scheme
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) {
    light = true; setTheme(light);
  }
})();
